package com.dopa.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.concurrent.Callable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "database2.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create table user(id TEXT Primary Key ,name TEXT,dob TEXT,gender TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists user");

    }

    public Boolean insertuserdata(String id,String name, String dob, String gender) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", id);
        contentValues.put("name", name);
        contentValues.put("dob", dob);
        contentValues.put("gender", gender);

        long result = DB.insert("user", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;

        }
    }

    public Boolean updateuserdata(String id,String name,String dob, String gender) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Cursor cus = DB.rawQuery("Select * from user where id = ?", new String[]{id});

        contentValues.put("name", name);
        contentValues.put("dob", dob);
        contentValues.put("gender", gender);

        if (cus.getCount() > 0) {
            long result = DB.update("user", contentValues, "id=?", new String[]{id});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Boolean deleteuserdata(String id) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Cursor cus = DB.rawQuery("Select * from user where id = ?", new String[]{id});

        if (cus.getCount() > 0) {
            long result = DB.delete("user", "id=?", new String[]{id});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public Cursor getdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        Cursor cus = DB.rawQuery("Select * from user", null);
        return cus;
    }
}


