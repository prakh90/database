package com.dopa.database;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5;
    Button first,next,prev,last;
    DBHelper DB;
    Cursor cus;
    int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        t1 = (TextView) findViewById(R.id.View);
        t2 = (TextView) findViewById(R.id.View2);
        t3 = (TextView) findViewById(R.id.View4);
        t4 = (TextView) findViewById(R.id.View5);
        first = (Button) findViewById(R.id.home);
        next = (Button) findViewById(R.id.next);
        prev = (Button) findViewById(R.id.prev);
        last = (Button) findViewById(R.id.end);
        DB = new DBHelper(this);
        cus = DB.getdata();
        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cus.moveToFirst();
                t1.setText(""+cus.getString(0));
                t2.setText(""+cus.getString(1));
                t3.setText(""+cus.getString(2));
                t4.setText(""+cus.getString(3));


            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cus.isLast()) {
                    Toast.makeText(MainActivity2.this, "Last Entry", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    cus.moveToNext();
                    t1.setText(""+cus.getString(0));
                    t2.setText(""+cus.getString(1));
                    t3.setText(""+cus.getString(2));
                    t4.setText(""+cus.getString(3));
                }

            }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(cus.isFirst()) {
                    Toast.makeText(MainActivity2.this, "First Entry", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    cus.moveToPrevious();
                    t1.setText(""+cus.getString(0));
                    t2.setText(""+cus.getString(1));
                    t3.setText(""+cus.getString(2));
                    t4.setText(""+cus.getString(3));
                }


            }
        });
        last.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cus.moveToLast();
                t1.setText(""+cus.getString(0));
                t2.setText(""+cus.getString(1));
                t3.setText(""+cus.getString(2));
                t4.setText(""+cus.getString(3));

            }
        });
        first.performClick();
    }

}