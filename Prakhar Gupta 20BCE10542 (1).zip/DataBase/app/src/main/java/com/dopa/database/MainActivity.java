package com.dopa.database;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button ins,del,upd,vi;
    EditText id,name,dob;
    RadioGroup rg;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ins = (Button) findViewById(R.id.insert);
        del = (Button) findViewById(R.id.delete);
        upd = (Button) findViewById(R.id.update);
        vi =(Button) findViewById(R.id.view);
        id= (EditText) findViewById(R.id.ID);
        name = (EditText) findViewById(R.id.name);
        dob = (EditText) findViewById(R.id.DOB);
        rg = (RadioGroup) findViewById(R.id.Radiogroup);

        DB = new DBHelper(this);
        ins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checking()) {
                    int a = rg.getCheckedRadioButtonId();
                    RadioButton temp = (RadioButton)  findViewById(a);
                    String se  =temp.getText().toString();
                    String i = id.getText().toString();
                    String n = name.getText().toString();
                    String d = dob.getText().toString();
                    boolean check = DB.insertuserdata(i, n, d, se);
                    if (check == true) {
                        Toast.makeText(MainActivity.this, "INSERTED", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(MainActivity.this, "ERROR WHILE INSERTING", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checking()) {
                    String i = id.getText().toString();
                    String n = name.getText().toString();
                    String d = dob.getText().toString();
                    int a = rg.getCheckedRadioButtonId();
                    RadioButton temp = (RadioButton) findViewById(a);
                    String se  =temp.getText().toString();
                    boolean check = DB.updateuserdata(i, n, d, se);
                    if (check == true) {
                        Toast.makeText(MainActivity.this, "UPDATED", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(MainActivity.this, "ERROR WHILE UPDATING", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        del.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String i = id.getText().toString();
                if(i.trim().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Enter ID", Toast.LENGTH_SHORT).show();
                }
                else {
                    Boolean check = DB.deleteuserdata(i);
                    if (check == true) {
                        Toast.makeText(MainActivity.this, "DELETED", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(MainActivity.this, "ERROR", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
        vi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,MainActivity2.class);
                startActivity(i);

            }
        });

    }

    public boolean checking()
    {
        int a = rg.getCheckedRadioButtonId();
        if(a==-1||id.getText().toString().trim().isEmpty()||name.getText().toString().trim().isEmpty()||dob.getText().toString().trim().isEmpty())
        {
            Toast.makeText(this, "Enter Every Data", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;

    }
}